num=int(input("Enter the Number:"))

for i in range(1,num):
    num=num*i
print("Factorial of given number is",num)
