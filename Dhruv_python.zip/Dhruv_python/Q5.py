num1=int(input("Enter the num 1:"))
num2=int(input("Enter the num 2:"))
temp=0
temp=num1
num1=num2
num2=temp

print("number after swapping:","num1:",num1,"num2:",num2,end="")
