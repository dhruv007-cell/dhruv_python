num=int(input("Enter the Number:"))
rev=0

while(num>0):
    dig=num%10
    rev=rev*10+dig
    num=num//10
    
print("The reverse of a num is:",rev)
    


