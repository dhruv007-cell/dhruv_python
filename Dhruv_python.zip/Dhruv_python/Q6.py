num=int(input("Enter the Number:"))
sum1=0
rem=0
while num>0:
    dig=num%10
    sum1=sum1+dig
    num=num//10
print("the sum of digit is:",sum1)
