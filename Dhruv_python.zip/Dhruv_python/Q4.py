num1=int(input("Enter the num 1:"))
num2=int(input("Enter the num 2:"))
num3=int(input("Enter the num 3:"))

if num1>num2 and num>num3:print("First number is greatest")
elif num2>num3:print("second number is greatest")
else: print("Third number is greatest")
