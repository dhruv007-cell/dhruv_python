num=int(input("Enter the num:"))
if num %2 == 0:
    print("it is even no")
else:print("It is odd")
