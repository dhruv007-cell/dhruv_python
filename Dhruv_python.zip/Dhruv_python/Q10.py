num=int(input("Enter the Number:"))
rem=0
rev=0
dig=0
n=num
while(num>0):
    dig=num%10
    rev=(rev*10)+dig
    num=num//10
    
if n==num:
    print("The no is palindrome")
else:print("not palindrome")
