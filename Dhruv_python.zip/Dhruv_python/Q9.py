num=float(input("Enter the Number:"))
arm=0
n=num
while num>0:
    rem=num%10;
    arm=arm+rem**3;
    num=num//10;

if n==arm:
        print("it is armstrong number")
else: print("it is not")    
