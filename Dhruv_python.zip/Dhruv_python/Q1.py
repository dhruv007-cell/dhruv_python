name="Utkarsh"
ID="321ABZ"
Email="abc1234@gmail.com"
des="Faculty"
pas="zzz@123"

print("Name:",name, end="            ")
print("Designation:",des)

print("ID:",ID, end="               ")
print("Password:",pas)

print("Email:",Email)
